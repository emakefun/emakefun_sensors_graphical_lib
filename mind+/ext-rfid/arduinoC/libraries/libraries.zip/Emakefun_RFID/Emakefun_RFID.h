#include<MFRC522_I2C.h>
//#include<Wire>

class Emakefun_RFID
{
  
};
